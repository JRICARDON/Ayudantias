from nltk import word_tokenize, NaiveBayesClassifier
from nltk import classify
from nltk import WordNetLemmatizer
from nltk.corpus import stopwords
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_recall_fscore_support
from sklearn import preprocessing
from sklearn.datasets import dump_svmlight_file
import scipy.io as sio
import random
import os, glob, re
import numpy
from scipy.sparse import vstack, hstack
import sys

import codecs

wordlemmatizer = WordNetLemmatizer()
commonwords = stopwords.words('english')

def labelled_text_extractor(raw_tweet):
	elements=raw_tweet.split(' ',1)
	label=0#negative
	if(int(elements[0].strip('"'))>0):
		label=1#positive
	return (elements[-1],label)

def word_extractor(text):
	text = text[1:-2]
	text = re.sub(r'@[^\n ]*','USERNAME',text)#sub a username by the word USERNAME
	text = re.sub(r'http[^\n ]*','URL',text)#sub an url by the word URL
	text = re.sub(r'([a-z])\1+', r'\1\1',text)#remove multiple letter by two
	#text = re.sub(r'[\.,:;]+',' ',text)
	#text = re.sub(r"'s",' is ',text)
	# Palabras de largo 1 (al inicio, medio o fin) se reemplazan por espacio
	#text = re.sub(r'^[a-zA-Z] ',' ',text)
	#text = re.sub(r' [a-zA-Z] ',' ',text)
	#text = re.sub(r' [a-zA-Z]$',' ',text)

	words=""
	wordtokens = [ wordlemmatizer.lemmatize(word.lower()) for word in word_tokenize(text.decode('utf-8', 'ignore')) ]#lowercase
	for word in wordtokens: 
		#if word not in commonwords:
				words+=" "+word	
	return words

def word_extractor_test(text):
	chars_to_remove = [':)',':-)',': )',':D','=)',':(',':-(',': (']
	rx = '[' + re.escape(''.join(chars_to_remove)) + ']'

	text = text[1:-2]
	text = re.sub(r'@[^\n ]*','USERNAME',text)#sub a username by the word USERNAME
	text = re.sub(r'http[^\n ]*','URL',text)#sub an url by the word URL
	text = re.sub(r'([a-z])\1+', r'\1\1',text)#remove multiple letter by two
	#text = re.sub(r'[\.,:;]+',' ',text)
	#text = re.sub(r"'s",' is ',text)
	# Palabras de largo 1 (al inicio, medio o fin) se reemplazan por espacio
	#text = re.sub(r'^[a-zA-Z] ',' ',text)
	#text = re.sub(r' [a-zA-Z] ',' ',text)
	#text = re.sub(r' [a-zA-Z]$',' ',text)
	text = re.sub(rx, '', text)

	words=""
	wordtokens = [ wordlemmatizer.lemmatize(word.lower()) for word in word_tokenize(text.decode('utf-8', 'ignore')) ]#lowercase
	for word in wordtokens: 
		#if word not in commonwords:
				words+=" "+word	
	return words

def main():

	dataname = sys.argv[1]
	
	SEED = 448
	random.seed(SEED)
	type_rep = 0#BINARY

	training_dataset = open(dataname)
	all_raw_tweets = training_dataset.readlines()

	training_dataset.close()

	labelled_tweets = []

	clines=0
	aux_ps = 0
	aux_ng = 0
	for raw_tweet in all_raw_tweets:
		text,label = labelled_text_extractor(raw_tweet)
		if label == 1:
			aux_ps += 1
		else:
			aux_ng += 1
		if text != None:
			labelled_tweets += [(text,label)]
		#if clines > 10000:
		#	break
		clines+=1	

	print "Cantidad positiva:", aux_ps
	print "Cantidad ngativa:",aux_ng

	tweets = [(word_extractor(text),label) for (text,label) in labelled_tweets ]

	limitngrams = 1
	count_vectorizer = CountVectorizer(ngram_range=(1, limitngrams), binary='False')

	x = count_vectorizer.fit_transform(numpy.asarray([tweet[0] for tweet in tweets ]))
	y = numpy.asarray([tweet[1] for tweet in tweets ])
	
	dump_svmlight_file(x, y.T, dataname+".SVMLIGHT", zero_based=True, comment=None, query_id=None)

main()



