import urllib
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.lda import LDA
from sklearn.qda import QDA
from matplotlib import pyplot as plt
import seaborn as sns 
import numpy as np

train_data_url = "http://statweb.stanford.edu/~tibs/ElemStatLearn/datasets/vowel.train"
test_data_url = "http://statweb.stanford.edu/~tibs/ElemStatLearn/datasets/vowel.test"
train_data_f = urllib.urlretrieve(train_data_url, "train_data.csv")
test_data_f = urllib.urlretrieve(test_data_url, "test_data.csv")

train_df = pd.DataFrame.from_csv('train_data.csv',header=0,index_col=0)
test_df = pd.DataFrame.from_csv('test_data.csv',header=0,index_col=0)

train_df.head()
test_df.tail()

from sklearn.preprocessing import StandardScaler
X = train_df.ix[:,'x.1':'x.10'].values
y = train_df.ix[:,'y'].values

Xtest = test_df.ix[:,'x.1':'x.10'].values
ytest = test_df.ix[:,'y'].values

X_std = StandardScaler().fit_transform(X)
X_std_test = StandardScaler().fit_transform(Xtest)

sklearn_pca = PCA(n_components=2)
sklearn_lda = LDA(n_components=2)

Xred_pca = sklearn_pca.fit_transform(X_std)
Xred_pca_test = sklearn_pca.transform(X_std_test)

Xred_lda = sklearn_lda.fit_transform(X_std,y)

cmap = plt.cm.get_cmap('Accent')
mclasses=(1,2,3,4,5,6,7,8,9)
mcolors = [cmap(i) for i in np.linspace(0,1,10)]
print mcolors
plt.figure(figsize=(12, 8))
for lab, col in zip(mclasses,mcolors):
    plt.scatter(Xred_pca[y==lab, 0],
                Xred_pca[y==lab, 1],
                label=lab,
                c=col)

plt.xlabel('Principal Component 1')
plt.ylabel('Principal Component 2')
leg = plt.legend(loc='upper right', fancybox=True)
plt.tight_layout()
plt.show()

cmap = plt.cm.get_cmap('Accent')
mclasses=(1,2,3,4,5,6,7,8,9)
mcolors = [cmap(i) for i in np.linspace(0,1,10)]
print mcolors
plt.figure(figsize=(12, 8))
for lab, col in zip(mclasses,mcolors):
    plt.scatter(Xred_lda[y==lab, 0],
                Xred_lda[y==lab, 1],
                label=lab,
                c=col)

plt.xlabel('LDA/Fisher Direction 1')
plt.ylabel('LDA/Fisher Direction 2')
leg = plt.legend(loc='upper right', fancybox=True)
plt.tight_layout()
plt.show()

sklearn_pca = PCA(n_components=10)
sklearn_lda = LDA(n_components=10)

Xred_pca = sklearn_pca.fit_transform(X_std)
Xred_pca_test = sklearn_pca.transform(X_std_test)

from sklearn.lda import LDA
lda_model = LDA()
lda_model.fit(X_std,y)
acc_train = lda_model.score(X_std,y)
acc_test = lda_model.score(X_std_test,ytest)
print acc_train
print acc_test


from sklearn.qda import QDA
lda_model = QDA()
lda_model.fit(X_std,y)
acc_train = lda_model.score(X_std,y)
acc_test = lda_model.score(X_std_test,ytest)
print acc_train
print acc_test


from sklearn.linear_model import LogisticRegression
lda_model = LogisticRegression(C=1)
lda_model.fit(X_std,y)
acc_train = lda_model.score(X_std,y)
acc_test = lda_model.score(X_std_test,ytest)
print acc_train
print acc_test


from sklearn.neighbors import KNeighborsClassifier
lda_model = KNeighborsClassifier(n_neighbors=10)
lda_model.fit(X_std,y)
acc_train = lda_model.score(X_std,y)
acc_test = lda_model.score(X_std_test,ytest)
print acc_train
print acc_test


