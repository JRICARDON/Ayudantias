######################################### 1  ######################################### 

import urllib

train_data_url = "http://www.inf.utfsm.cl/~jnancu/stanford-subset/polarity.train"
test_data_url = "http://www.inf.utfsm.cl/~jnancu/stanford-subset/polarity.dev"

train_data_f = urllib.urlretrieve(train_data_url, "train_data.csv")
test_data_f = urllib.urlretrieve(test_data_url, "test_data.csv")

import pandas as pd

ftr = open("train_data.csv", "r")
fts = open("test_data.csv", "r")

rows = [line.split(" ",1) for line in ftr.readlines()]
train_df = pd.DataFrame(rows, columns=['Sentiment','Text'])
train_df['Sentiment'] = pd.to_numeric(train_df['Sentiment'])

rows = [line.split(" ",1) for line in fts.readlines()]
test_df = pd.DataFrame(rows, columns=['Sentiment','Text'])
test_df['Sentiment'] = pd.to_numeric(test_df['Sentiment'])

train_df.shape
test_df.shape


import numpy as np 
np.mean([len(s.split(" ")) for s in train_df.Text])

######################################### 2  ######################################### 

import re
import time
from sklearn.feature_extraction.text import CountVectorizer        
from nltk.stem.porter import PorterStemmer
from nltk import WordNetLemmatizer, word_tokenize
from nltk.corpus import stopwords
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB,BernoulliNB
from sklearn.svm import LinearSVC


def word_extractor(text):
	wordlemmatizer = WordNetLemmatizer()
	commonwords = stopwords.words('english')
	text = re.sub(r'([a-z])\1+', r'\1\1',text)#remove multiple letter by two
	words=""
	wordtokens = [ wordlemmatizer.lemmatize(word.lower()) \
				for word in word_tokenize(text.decode('utf-8', 'ignore')) ]
	for word in wordtokens: 
		if word not in commonwords:
				words+=" "+word	
	return words

def word_extractor2(text):
	stemmer = PorterStemmer()
	commonwords = stopwords.words('english')
	text = re.sub(r'@[^\n ]*','USERNAME',text)#sub a username by the word USERNAME
	text = re.sub(r'http[^\n ]*','URL',text)#sub an url by the word URL
	text = re.sub(r'([a-z])\1+', r'\1\1',text)#remove multiple letter by two
	words=""
	wordtokens = [ stemmer.stem(word.lower()) for word in word_tokenize(text.decode('utf-8', 'ignore')) ]#lowercase
	for word in wordtokens: 
		if word not in commonwords:
				words+=" "+word	
	return words

from sklearn.metrics import classification_report
def score_the_model(model,x,y,xt,yt,text):
	start_t = time.time()
	acc_tr = model.score(x,y)
	acc_test = model.score(xt[:-1],yt[:-1])
	print "Training Accuracy %s: %f"%(text,acc_tr)
	print "Test Accuracy %s: %f"%(text,acc_test)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Testing the Model: %f Secs.\n\n"%elapsed_time
	print "Detailed Analysis Testing Results ..."
	print(classification_report(yt, model.predict(xt), target_names=['positive','negative']))

def do_SVM(x,y,xt,yt):
	start_t = time.time()
	Cs = [0.01,0.1,10,100,1000]
	for C in Cs:
		print "El valor de C que se esta probando: %f"%C
		model = LinearSVC(C=C)
		model = model.fit(x, y)
		elapsed_time = time.time() - start_t
		print "Elapsed Time Training the Model: %f Secs."%elapsed_time
		score_the_model(model,x,y,xt,yt,"SVM")
	return model

def do_LOGIT(x,y,xt,yt):
	start_t = time.time()
	Cs = [0.01,0.1,10,100,1000]
	for C in Cs:
		print "El valor de C que se esta probando: %f"%C
		model = LogisticRegression(penalty='l2',C=C)
		model = model.fit(x, y)
		elapsed_time = time.time() - start_t
		print "Elapsed Time Training the Model: %f Secs."%elapsed_time
		score_the_model(model,x,y,xt,yt,"LOGISTIC")
	return model

def do_MULTINOMIAL(x,y,xt,yt):
	print type(x)
	print type(y)
	start_t = time.time()
	model = MultinomialNB()
	model = model.fit(x, y)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Training the Model: %f Secs."%elapsed_time
	score_the_model(model,x,y,xt,yt,"MULTINOMIAL")
	return model

def do_NAIVE_BAYES(x,y,xt,yt):
	start_t = time.time()
	model = BernoulliNB()
	model = model.fit(x, y)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Training the Model: %f Secs."%elapsed_time
	score_the_model(model,x,y,xt,yt,"BernoulliNB")
	return model

from sklearn.datasets import load_svmlight_file
from sklearn.datasets import dump_svmlight_file

def get_data(filename):
    data = load_svmlight_file(filename)
    return data[0], data[1]

def read_polarity(datapath):
	all_X, all_y = get_data(datapath)

	print "Size X: %d %d"%(all_X.shape[0],all_X.shape[1])
	print "Size Y: %d"%all_y.shape[0]

	n_all_train = 3554
	n_all_test = 3554

	X_train = all_X[:n_all_train][:]
	Y_train = all_y[:n_all_train]
	X_test = all_X[n_all_train:][:]
	Y_test = all_y[n_all_train:]

	return X_train,Y_train,X_test,Y_test	
######## 

import numpy as np
from sklearn.feature_extraction.text import CountVectorizer 

texts_train = [word_extractor2(text) for text in train_df.Text]
texts_test = [word_extractor2(text) for text in test_df.Text]
vectorizer = CountVectorizer(ngram_range=(1, 1), binary='False')
vectorizer.fit(np.asarray(texts_train))
features_train = vectorizer.transform(texts_train)
features_test = vectorizer.transform(texts_test)
labels_train = np.asarray((train_df.Sentiment.astype(float)+1)/2.0)
labels_test = np.asarray((test_df.Sentiment.astype(float)+1)/2.0)

vocab = vectorizer.get_feature_names()
dist=list(np.array(features_train.sum(axis=0)).reshape(-1,))
for tag, count in zip(vocab, dist):
    print count, tag

model = do_MULTINOMIAL(features_train,labels_train,features_test,labels_test)

test_pred = model.predict_proba(features_test)
import random
spl = random.sample(xrange(len(test_pred)), 15)
for text, sentiment in zip(test_df.Text[spl], test_pred[spl]):
    print sentiment, text

do_NAIVE_BAYES(features_train,labels_train,features_test,labels_test)
