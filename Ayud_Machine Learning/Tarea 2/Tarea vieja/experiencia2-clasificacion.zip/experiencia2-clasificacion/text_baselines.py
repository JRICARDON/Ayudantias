from sklearn.datasets import load_svmlight_file
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB,BernoulliNB
from sklearn.svm import LinearSVC

import time

def get_data(filename):
    data = load_svmlight_file(filename)
    return data[0], data[1]

def score_the_model(model,x,y,xt,yt,text):
	start_t = time.time()
	acc_tr = model.score(x,y)
	acc_test = model.score(xt[:-1],yt[:-1])
	print "Training Accuracy %s: %f"%(text,acc_tr)
	print "Test Accuracy %s: %f"%(text,acc_test)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Testing the Model: %f Secs.\n\n"%elapsed_time

def do_SVM(x,y,xt,yt):
	start_t = time.time()
	Cs = [0.01,0.1,10,100,1000]
	for C in Cs:
		print "El valor de C que se esta probando: %f"%C
		model = LinearSVC(C=C)
		model = model.fit(x, y)
		elapsed_time = time.time() - start_t
		print "Elapsed Time Training the Model: %f Secs."%elapsed_time
		score_the_model(model,x,y,xt,yt,"SVM")

def do_LOGIT(x,y,xt,yt):
	start_t = time.time()
	Cs = [0.01,0.1,10,100,1000]
	for C in Cs:
		print "El valor de C que se esta probando: %f"%C
		model = LogisticRegression(penalty='l2',C=C)
		model = model.fit(x, y)
		elapsed_time = time.time() - start_t
		print "Elapsed Time Training the Model: %f Secs."%elapsed_time
		score_the_model(model,x,y,xt,yt,"LOGISTIC")

def do_MULTINOMIAL(x,y,xt,yt):
	print type(x)
	print type(y)
	start_t = time.time()
	model = MultinomialNB()
	model = model.fit(x, y)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Training the Model: %f Secs."%elapsed_time
	score_the_model(model,x,y,xt,yt,"MULTINOMIAL")

def do_BERNOULLI(x,y,xt,yt):
	start_t = time.time()
	model = BernoulliNB()
	model = model.fit(x, y)
	elapsed_time = time.time() - start_t
	print "Elapsed Time Training the Model: %f Secs."%elapsed_time
	score_the_model(model,x,y,xt,yt,"BernoulliNB")


def read_polarity(datapath):
	all_X, all_y = get_data(datapath)

	print "Size X: %d %d"%(all_X.shape[0],all_X.shape[1])
	print "Size Y: %d"%all_y.shape[0]

	n_all_train = 3554
	n_all_test = 3554

	X_train = all_X[:n_all_train][:]
	Y_train = all_y[:n_all_train]
	X_test = all_X[n_all_train:][:]
	Y_test = all_y[n_all_train:]

	return X_train,Y_train,X_test,Y_test	

start_t = time.time()

X_train,Y_train,X_test,Y_test = read_polarity("stanford-subset/polarity.SVMLIGHT")

elapsed_time = time.time() - start_t
print "Elpased Time Reading Data: %f Secs."%elapsed_time

print "Size X Training: %d %d"%(X_train.shape[0],X_train.shape[1])
print "Size Y Training: %d"%Y_train.shape[0]
print "Size X Test: %d %d"%(X_test.shape[0],X_test.shape[1])
print "Size Y Test: %d"%Y_test.shape[0]

#do_LOGIT(X_train,Y_train,X_test,Y_test)
do_MULTINOMIAL(X_train,Y_train,X_test,Y_test)
#do_BERNOULLI(X_train,Y_train,X_test,Y_test)
#do_SVM(X_train,Y_train,X_test,Y_test)