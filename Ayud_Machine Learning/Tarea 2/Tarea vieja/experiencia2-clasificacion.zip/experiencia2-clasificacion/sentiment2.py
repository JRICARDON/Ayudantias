import urllib

train_data_url = "http://www.inf.utfsm.cl/~jnancu/stanford-subset/polarity.train"
test_data_url = "http://www.inf.utfsm.cl/~jnancu/stanford-subset/polarity.dev"

train_data_f = urllib.urlretrieve(train_data_url, "train_data.csv")
test_data_f = urllib.urlretrieve(test_data_url, "test_data.csv")

import pandas as pd

ftr = open("train_data.csv", "r")
fts = open("test_data.csv", "r")

rows = [line.split(" ",1) for line in ftr.readlines()]
train_df = pd.DataFrame(rows, columns=['Sentiment','Text'])
train_df['Sentiment'] = pd.to_numeric(train_df['Sentiment'])

rows = [line.split(" ",1) for line in fts.readlines()]
test_df = pd.DataFrame(rows, columns=['Sentiment','Text'])
test_df['Sentiment'] = pd.to_numeric(test_df['Sentiment'])

train_df.shape
test_df.shape


import numpy as np 
np.mean([len(s.split(" ")) for s in train_df.Text])

import re, nltk    
from nltk.stem.porter import PorterStemmer
stemmer = PorterStemmer()
def stem_tokens(tokens, stemmer):
    stemmed = []
    for item in tokens:
        stemmed.append(stemmer.stem(item))
    return stemmed

def tokenize(text):
    text = re.sub("[^a-zA-Z]", " ", text)
    text = text.lower()
    tokens = nltk.word_tokenize(text.decode('utf-8', 'ignore'))
    stems = stem_tokens(tokens, stemmer)
    words=""
    for word in stems: 
		#if word not in commonwords:
				words+=" "+word	
    return words

tokenize("I love to eat cake")
tokenize("I love eating cake")
tokenize("I loved eating cake")
tokenize("I do not love eating cake")
tokenize("I don't love eating cake")

texts_train = [tokenize(text) for text in train_df.Text]
texts_test = [tokenize(text) for text in test_df.Text]

from sklearn.feature_extraction.text import CountVectorizer    
limitngrams = 1
vectorizer = CountVectorizer(ngram_range=(1, limitngrams), binary='False')
vectorizer.fit(np.asarray(texts_train))

train_features = vectorizer.transform(texts_train)
vocab = vectorizer.get_feature_names()	

test_features = vectorizer.transform(texts_test)

Y_train = np.asarray((train_df.Sentiment.astype(float)+1)/2.0)
Y_test = np.asarray((test_df.Sentiment.astype(float)+1)/2.0)

from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB,BernoulliNB
from sklearn.svm import LinearSVC

def score_the_model(model,x,y,xt,yt,text):
	acc_tr = model.score(x,y)
	acc_test = model.score(xt[:-1],yt[:-1])
	print "Training Accuracy %s: %f"%(text,acc_tr)
	print "Test Accuracy %s: %f"%(text,acc_test)

def do_MULTINOMIAL(x,y,xt,yt):
	print type(x)
	print type(y)
	model = MultinomialNB()
	model = model.fit(x, y)
	score_the_model(model,x,y,xt,yt,"MULTINOMIAL")

do_MULTINOMIAL(train_features,Y_train,test_features,Y_test)

